package com.zeroice.zerodonate

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType

class MainActivity : Activity() {
    private val troopNames = listOf(
        "رامي", "مقاتل", "عملاق", "ساحر", "بالون", "تنين",
        "تنين كهربائي", "بيكا", "مينيون", "راكب خنزير", "غولم", "فالكيري"
    )
    private val available = mutableMapOf<String, Int>()
    private val requested = mutableMapOf<String, Int>()
    private lateinit var resultText: TextView
    private lateinit var availableBox: LinearLayout
    private lateinit var requestedBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        buildRows(availableBox, available, "قواتك المتاحة")
        buildRows(requestedBox, requested, "القوات المطلوبة")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(13, 25, 39))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "ZERO DONATE"
            textSize = 28f
            setTextColor(Color.rgb(70, 220, 170))
            gravity = Gravity.CENTER
        }
        content.addView(title)
        content.addView(label("مساعد التبرع المطابق", 17f, Color.WHITE))
        content.addView(label(
            "نسخة أولية: أدخل القوات المتاحة لديك والقوات التي طلبها العضو. سيحسب التطبيق المطابقة فقط، ولن يضغط داخل اللعبة تلقائياً.",
            14f, Color.LTGRAY
        ))
        content.addView(sectionTitle("1) قواتك المتاحة"))
        availableBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(availableBox)
        content.addView(sectionTitle("2) طلب العضو"))
        requestedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(requestedBox)

        val calculate = Button(this).apply {
            text = "احسب القوات المطابقة"
            setOnClickListener { calculateMatches() }
        }
        content.addView(calculate)

        resultText = label("ستظهر نتيجة المطابقة هنا.", 16f, Color.WHITE)
        resultText.setPadding(0, 18, 0, 18)
        content.addView(resultText)

        val reset = Button(this).apply {
            text = "مسح الأرقام"
            setOnClickListener {
                available.clear()
                requested.clear()
                buildRows(availableBox, available, "قواتك المتاحة")
                buildRows(requestedBox, requested, "القوات المطلوبة")
                resultText.text = "تم مسح الأرقام."
            }
        }
        content.addView(reset)
        root.addView(scroll)
        setContentView(root)
    }

    private fun buildRows(container: LinearLayout, target: MutableMap<String, Int>, heading: String) {
        container.removeAllViews()
        troopNames.forEach { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 5, 0, 5)
            }
            val nameView = TextView(this).apply {
                text = name
                textSize = 14f
                setTextColor(Color.WHITE)
            }
            row.addView(nameView, LinearLayout.LayoutParams(0, -2, 1f))
            val count = EditText(this).apply {
                hint = "العدد"
                inputType = InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
                textSize = 14f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.LTGRAY)
                setBackgroundColor(Color.rgb(37, 53, 69))
                setPadding(12, 6, 12, 6)
                filters = arrayOf(android.text.InputFilter.LengthFilter(3))
                setText(target[name]?.takeIf { it > 0 }?.toString() ?: "")
                addTextChangedListener(SimpleTextWatcher { value ->
                    target[name] = value.toIntOrNull()?.coerceAtLeast(0) ?: 0
                })
            }
            row.addView(count, LinearLayout.LayoutParams(110, 48))
            container.addView(row)
        }
    }

    private fun calculateMatches() {
        val lines = mutableListOf<String>()
        var total = 0
        troopNames.forEach { name ->
            val have = available[name] ?: 0
            val want = requested[name] ?: 0
            val match = minOf(have, want)
            if (match > 0) {
                lines.add("• $name: $match")
                total += match
            }
        }
        resultText.text = if (lines.isEmpty()) {
            "لا توجد قوات مطابقة متاحة حالياً."
        } else {
            "القوات المطابقة التي يمكنك التبرع بها:\n${lines.joinToString("\n")}\n\nالمجموع: $total"
        }
    }

    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue
        textSize = size
        setTextColor(color)
        setPadding(0, 8, 0, 8)
    }

    private fun sectionTitle(value: String) = TextView(this).apply {
        text = value
        textSize = 18f
        setTextColor(Color.rgb(70, 220, 170))
        setPadding(0, 16, 0, 6)
    }
}
